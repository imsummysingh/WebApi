﻿using Microsoft.AspNetCore.Identity;

namespace JWTAuthenticationWithSwagger.Authentication
{
    public class ApplicationUser : IdentityUser
    {
    }
}
